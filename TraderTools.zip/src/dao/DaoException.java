/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

/**
 *
 * @author е
 */
public class DaoException extends Exception{

    public DaoException(String message) {
        super(message);
    }

}
