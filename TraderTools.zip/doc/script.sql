/*
Created		18.02.2009
Modified		30.03.2009
Project		
Model			
Company		
Author		
Version		
Database		PostgreSQL 8.1 
*/



/* Drop Referential Integrity Triggers */





/* Drop User-Defined Triggers */



/* Drop Domains */



/* Drop Procedures */
Drop FUNCTION CalcAmountLeft (product_id_param integer);
Drop FUNCTION CalcInvoiceSum (invoice_id_param integer);
Drop FUNCTION CalcInvoiceProductCost (invoice_product_id_param integer);



/* Drop Rules */



/* Drop Views */



/* Drop Indexes */



/* Drop Tables */
Drop table "bank" Cascade;
Drop table "account" Cascade;
Drop table "user" Cascade;
Drop table "request_product" Cascade;
Drop table "request" Cascade;
Drop table "bill" Cascade;
Drop table "invoice_product" Cascade;
Drop table "invoice" Cascade;
Drop table "supply" Cascade;
Drop table "customer" Cascade;
Drop table "category" Cascade;
Drop table "product" Cascade;



/* Drop Sequences */



/* Create Domains */



/* Create Sequences */



/* Create Tables */


Create table "product"
(
	"id" Serial NOT NULL,
	"title" Varchar(100) NOT NULL UNIQUE,
	"article" Varchar(20),
	"category_id" Integer,
 primary key ("id")
) Without Oids;


Create table "category"
(
	"id" Serial NOT NULL,
	"title" Varchar(100) NOT NULL UNIQUE,
 primary key ("id")
) Without Oids;


Create table "customer"
(
	"id" Serial NOT NULL,
	"title" Varchar(100) NOT NULL UNIQUE,
	"is_supplier" Boolean NOT NULL,
	"ITN" Varchar(50),
	"account" Varchar(200),
	"address" Varchar(100),
	"phone" Varchar(100),
	"email" Varchar(100),
	"details" Varchar(100),
	"comment" Varchar(200),
 primary key ("id")
) Without Oids;


Create table "supply"
(
	"product_id" Integer NOT NULL,
	"seller_id" Integer NOT NULL,
	"title_alias" Varchar(100),
	"actual_price" Numeric(20,2) NOT NULL,
	"amount_left" Integer,
	"amount_min" Integer NOT NULL Default 1,
	"default_order_amount" Integer,
	"prev_price" Numeric(20,2),
 primary key ("product_id","seller_id")
) Without Oids;


Create table "invoice"
(
	"id" Serial NOT NULL,
	"buyer_id" Integer NOT NULL,
	"seller_id" Integer NOT NULL,
	"sum" Numeric(20,2),
	"creation_date" Timestamp,
 primary key ("id")
) Without Oids;


Create table "invoice_product"
(
	"id" Serial NOT NULL,
	"invoice_id" Integer NOT NULL,
	"product_id" Integer NOT NULL,
	"price" Numeric(20,2) NOT NULL,
	"amount" Integer NOT NULL,
	"cost" Numeric(20,2),
 primary key ("id")
) Without Oids;


Create table "bill"
(
	"id" Serial NOT NULL,
	"sender_id" Integer NOT NULL,
	"receiver_id" Integer NOT NULL,
	"money" Numeric(20,2) NOT NULL,
	"creation_date" Timestamp NOT NULL,
	"purpose" Varchar(200),
 primary key ("id")
) Without Oids;


Create table "request"
(
	"id" Serial NOT NULL,
	"sender_id" Integer NOT NULL,
	"receiver_id" Integer NOT NULL,
	"creation_date" Timestamp,
 primary key ("id")
) Without Oids;


Create table "request_product"
(
	"id" Serial NOT NULL,
	"request_id" Integer NOT NULL,
	"product_id" Integer NOT NULL,
	"amount" Integer NOT NULL,
 primary key ("id")
) Without Oids;


Create table "user"
(
	"id" Serial NOT NULL,
	"username" Varchar(100),
	"password" Varchar(100),
	"rights" Integer,
 primary key ("id")
) Without Oids;


Create table "account"
(
	"id" Serial NOT NULL,
	"bank_id" Integer NOT NULL,
	"customer_id" Integer NOT NULL,
	"number" Varchar(20) NOT NULL UNIQUE,
 primary key ("id")
) Without Oids;


Create table "bank"
(
	"id" Serial NOT NULL,
	"title" Varchar(100) NOT NULL,
	"address" Varchar(100) NOT NULL,
	"loro_account" Char(20) NOT NULL,
	"BIK" Varchar(20) NOT NULL,
 primary key ("id")
) Without Oids;



/* Create Tab 'Others' for Selected Tables */


/* Create Alternate Keys */



/* Create Indexes */



/* Create Foreign Keys */

Alter table "supply" add  foreign key ("product_id") references "product" ("id") on update cascade on delete restrict;

Alter table "invoice_product" add  foreign key ("product_id") references "product" ("id") on update restrict on delete restrict;

Alter table "request_product" add  foreign key ("product_id") references "product" ("id") on update restrict on delete restrict;

Alter table "product" add  foreign key ("category_id") references "category" ("id") on update cascade on delete restrict;

Alter table "invoice" add  foreign key ("buyer_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "supply" add  foreign key ("seller_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "bill" add  foreign key ("sender_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "request" add  foreign key ("receiver_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "invoice" add  foreign key ("seller_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "request" add  foreign key ("sender_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "bill" add  foreign key ("receiver_id") references "customer" ("id") on update cascade on delete restrict;

Alter table "account" add  foreign key ("customer_id") references "customer" ("id") on update restrict on delete restrict;

Alter table "invoice_product" add  foreign key ("invoice_id") references "invoice" ("id") on update cascade on delete restrict;

Alter table "request_product" add  foreign key ("request_id") references "request" ("id") on update cascade on delete restrict;

Alter table "account" add  foreign key ("bank_id") references "bank" ("id") on update restrict on delete restrict;



/* Create Procedures */
CREATE OR REPLACE FUNCTION CalcAmountLeft (product_id_param integer)
  RETURNS void AS
$BODY$UPDATE supply 
SET amount_left = ( 
(SELECT SUM(ip.amount) FROM invoice_product ip, invoice i WHERE ip.product_id = $1 AND i.buyer_id = 0
AND ip.invoice_id = i.id) - 
(SELECT SUM(ip.amount) FROM invoice_product ip, invoice i WHERE ip.product_id = $1 AND i.seller_id = 0
AND ip.invoice_id = i.id)

)WHERE (supply.product_id = $1 AND supply.seller_id = 0);
  $BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION CalcAmountLeft (integer) OWNER TO postgres;
COMMENT ON FUNCTION CalcAmountLeft (integer) IS 
'��������� ������������� ���-�� ������ �� ������, ����������� �� ��������� ��������� � ������ ��� customer.id = 0';

CREATE OR REPLACE FUNCTION CalcInvoiceSum (invoice_id_param integer)
  RETURNS void AS
$BODY$UPDATE invoice 
SET sum = ( 
 SELECT SUM(ip.cost) FROM invoice_product ip WHERE ip.invoice_id = $1

)WHERE invoice.id = $1;
  $BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION CalcInvoiceSum (integer) OWNER TO postgres;
COMMENT ON FUNCTION CalcInvoiceSum (integer) IS '������������� ����� ���������, ����������� �� �� �������';

CREATE OR REPLACE FUNCTION CalcInvoiceProductCost (invoice_product_id_param integer)
  RETURNS void AS
$BODY$UPDATE invoice_product 
SET cost = ( 
(SELECT ip.amount FROM invoice_product ip WHERE ip.id = $1) *
(SELECT ip.price FROM invoice_product ip WHERE ip.id = $1)

)WHERE id = $1;
  $BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION CalcInvoiceProductCost (integer) OWNER TO postgres;
COMMENT ON FUNCTION CalcInvoiceProductCost (integer) IS '������������� ��������� ������ � ���������';




/* Create Views */



/* Create Rules */



/* Create Referential Integrity Triggers */





/* Create User-Defined Triggers */



/* Create Roles */



/* Add Roles To Roles */



/* Create Role Permissions */
/* Role permissions on tables */

/* Role permissions on views */

/* Role permissions on procedures */


INSERT into customer (id, title, is_supplier) VALUES (0, '�������', true)




